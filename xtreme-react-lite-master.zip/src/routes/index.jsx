import Fulllayout from '../layouts/fulllayout.jsx';

var indexRoutes = [
    { path: '/', name: 'Starter', component: Fulllayout }
];

export default indexRoutes;
